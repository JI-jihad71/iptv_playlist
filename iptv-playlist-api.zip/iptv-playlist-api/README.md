# IPTV Playlist API (Vercel)

Node.js 20+ serverless API that fetches an upstream M3U playlist and exposes M3U/M3U8 and JSON responses.

## Endpoints

- `/api/playlist` — M3U (default)
- `/api/playlist?format=m3u` — M3U
- `/api/playlist?format=m3u8` — M3U8 playlist response
- `/api/playlist?format=json` — JSON channel data
- `/api/playlist?format=health` — health check
- `/api/playlist?format=json&limit=20&offset=0` — JSON pagination
- `/api/playlist?format=json&group=Sports` — exact category filter
- `/api/playlist?format=json&q=cricket` — search channels
- `/api/playlist?format=m3u&group=Sports` — filtered M3U

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. Import the repository at https://vercel.com/new.
3. Optionally add `UPSTREAM_M3U_URL` in Project Settings → Environment Variables.
4. Deploy.

No third-party npm dependencies are required. Use Node.js 20 or later.

## Important limitations

- The upstream provider must permit requests from your Vercel deployment. This code does not bypass 403, authentication, IP allowlists, or other access controls.
- Use only playlist sources and streams you are authorized to access and redistribute.
- M3U output is reconstructed from channel metadata and stream URLs. Some non-channel directives/comments from the original playlist may not be retained.
- This is a playlist proxy, not a media-stream proxy. Channel playback still depends on the original stream URLs and their access rules.
- The cache headers allow platform caching; behavior depends on the hosting cache layer.
